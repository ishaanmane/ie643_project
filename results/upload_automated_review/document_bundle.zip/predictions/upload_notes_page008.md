[Diagram: A single filter with 3 channels, labeled "Single channel map".]

$$h_i \times w_i \quad (\text{kernel size}, \text{stride}, \text{padding}) \qquad h_0 \times w_0$$

[Diagram: A 16x16 input grid (labeled 16) being convolved with several 5x5 filters ($f_1, f_2, \dots$) — each producing an output grid of size 8x8.]