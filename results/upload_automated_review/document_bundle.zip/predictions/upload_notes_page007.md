[Diagram: A grid of 3x3 pixel patches (input feature map) feeding into separate 3x3 filter kernels, each producing a single output channel — "Channels of output conv. feat map".]

num of filters