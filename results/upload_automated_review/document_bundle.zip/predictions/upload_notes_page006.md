## Local rot. fields.

[Diagram: A grid over a hand shape, with several colored boxes (red, green, purple) highlighting local regions, labeled "Conv. feat. map".]

$$\vdots$$

**equivariant to transformations in orig. input**

[Diagram: Two identical hand shapes, one rotated slightly relative to the other, labeled "rotations / zoom operations".]