# 1. Point processing

[Diagram: A grid $I$ (left) transforms via an arrow into a grid $I'$ with one pixel highlighted red.]

$$I'(x,y) = f(I(x,y))$$

# 2. Neighbourhood processing:

[Diagram: A grid $I$ (left) around a pixel has a circle drawn around it, transforming via an arrow into a grid $I'$ with the same pixel highlighted red.]

$$I'(x,y) = f(I(N(x,y)))$$