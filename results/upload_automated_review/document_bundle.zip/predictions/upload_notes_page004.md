$$I'(x,y) = \sum_{i} \sum_{j} H(i,j) \cdot I(x(i),y(j))$$

[Diagram: A grid of pixels from an image $I$ at $(x,y)$ (num rows x num cols $\rightarrow$ pixel resolution), connected via a curved arrow to a smaller filter/kernel grid.]

Correlation $\rightarrow$ Convolution

[Diagram: A second grid of pixels from another image, connected via a curved arrow to "Class 3".]

filter / kernel || learnable in NN.