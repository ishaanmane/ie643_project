$$\frac{\partial e}{\partial w_f^l} = \delta^{l+1}$$

[Diagram: A 5x5 box labeled "LeNet" feeding into a chain of boxes.]

Max-pooling, Avg-pool, Min-pool, Mixed-pool, frac-pool, dynamic pooling

[Diagram: A 2x2 grid of red squares (pooling region) over a larger grid, with arrows connecting each red square's max value to the output neuron.]