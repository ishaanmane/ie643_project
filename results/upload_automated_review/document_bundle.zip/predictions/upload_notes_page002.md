[Diagram: A grid of pixels labeled "red intensity" mapping $\{0,1,\dots255\} \to [0,1]$.]

$$R, G, B \quad \text{"pixel values"}$$

$$I(x,y) \to (R,G,B)$$

$$I: \{1,2\dots r\} \times \{1,\dots c\} \to \{0,1,\dots 255\}^3$$