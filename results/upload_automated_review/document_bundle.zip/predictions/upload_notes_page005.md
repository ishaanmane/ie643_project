[Diagram: A 2D grid of pixels (rows, cols) — "col1", "col2", ..., "colM" — feeding into a column vector of pixel values ($N=4$, circled "100").]

$$z = \sum_j w_j x_j$$
$$a = \phi(z)$$

[Diagram: A 5x5 grid with a red-highlighted 3x3 sub-grid, labeled "5x5".]

Striding (cols + rows)

$$\underbrace{w_1}_{w_1}, \underbrace{w_2}_{w_2}, \underbrace{w_3}_{w_3}$$

$$z = \sum_i w_i p(x(i), y(i))$$
$$a = \phi(z)$$