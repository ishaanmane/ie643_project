## Recap.

**Representing digital images**

**Grayscale:**

[Diagram: A grid of pixels with one circled, labeled "pixel".]

$$I: \{1,2\dots r\} \times \{1,\dots c\} \longrightarrow \{0,1,\dots 255\}$$

- pixel $\rightarrow$ pixel intensity $\rightarrow$ grayscale level $\in \{0,1,2\dots 255\}$

$$[0,1]$$

0 — black, 255 — white