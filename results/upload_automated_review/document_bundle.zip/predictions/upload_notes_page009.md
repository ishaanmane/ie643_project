5x5x8 channel (video based conv)

12 such filters → 12 channel output

[Diagram: A 4x4 grid of 12 channels feeding into a 30-channel layer.]

4x4x12 → 30